# -*- coding: utf-8 -*-
"""
Created on Wed Sep 18 15:46:08 2024

@author: School
"""

from .tools.testcommands import *

tnode0 = testnode(0,'COMT',125)
#buffer random number log generation
