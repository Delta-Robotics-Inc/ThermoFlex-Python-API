from .controls import discover
#from .network import nodenet
#from .devices import node, muscle

#my library is the brains of the operation. Everything happens here. 
#make Markdown file
#Getting Started, Markdown with commands, Basic tutorial