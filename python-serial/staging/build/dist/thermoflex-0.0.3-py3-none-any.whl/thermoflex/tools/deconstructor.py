import serial as s

STARTBYTE = 0x7E
PROTOVER = 0x01
SENDID = [0x01,0x02,0x03]
IDTYPE = 0x00
CHECKSUM = 0xFF
PROTOSIZE = 1
IDTYPESIZE = 1
IDSIZE = 3
CHECKSUM = 1

def packet_deconstruction(data):
    for x in data:
        data = 
        
        
    
    